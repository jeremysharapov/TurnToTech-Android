package com.example.jeremy.parentleash;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import org.json.JSONObject;


import java.io.DataOutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {

    static EditText username, latitude, longitude, radius;
    static String json_url;
    static String Username, Latitude, Longitude, Radius;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = (EditText) findViewById(R.id.Username);
        latitude = (EditText) findViewById(R.id.Latitude);
        longitude = (EditText) findViewById(R.id.Longitude);
        radius = (EditText) findViewById(R.id.Radius);
    }

    public void createProfile(View view) {
        Username = username.getText().toString();
        Latitude = latitude.getText().toString();
        Longitude = longitude.getText().toString();
        Radius = radius.getText().toString();
        json_url = "https://turntotech.firebaseio.com/digitalleash/" + Username + ".json";
        new GetData().execute(json_url);
    }

    public class GetData extends AsyncTask<String, String, Void> {

        HttpURLConnection urlConnection;

        @Override
        protected Void doInBackground(String... args) {


            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("username", MainActivity.Username);
                jsonObject.put("latitude", MainActivity.Latitude);
                jsonObject.put("longitude", MainActivity.Longitude);
                jsonObject.put("radius", MainActivity.Radius);
                String json = jsonObject.toString();

                URL url = new URL(args[0]);
                HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
                httpCon.setRequestMethod("PUT");
                httpCon.setDoOutput(true);
                httpCon.setRequestProperty("Content-Type", "application/json");
                httpCon.setRequestProperty("Accept", "application/json");
                httpCon.setRequestProperty( "charset", "utf-8");
                httpCon.setRequestProperty( "Content-Length", Integer.toString( json.length() ));
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(httpCon.getOutputStream());
                outputStreamWriter.write(json);
                outputStreamWriter.flush();
                outputStreamWriter.close();
                Log.e("ConnectionStatus", String.valueOf(httpCon.getResponseCode()));
                httpCon.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
